#!/data/data/com.termux/files/usr/bin/python

from SkipAdsTV import helpers

helpers.app_start()
